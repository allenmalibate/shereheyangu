<!DOCTYPE html>

<html>
    <head>

        <!-- meta -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Sherehe Blog</title>        
        <!-- stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
          
        <link rel="stylesheet" href="css/style.css">

    </head>

    <body>

       <?php include 'inc/header.inc.php';?>

        <main style="margin-top: 72px;">
            <div class="container">
                <div class="row">

                    <!-- blog-contents -->
                    <section class="col-md-8">

                        <article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto4.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Ms Queen Kitchen Party</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->

                          <article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto3.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Mr &  Mrs Chacha Wedding Ceremony</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->

                          <article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto5.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Mr &  Mrs J.Chingx Wedding Ceremony</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->

<article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto1.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Ms Mercy Send Off Ceremony</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->

                         <article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto2.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Mr &  Mrs Gerege Wedding Ceremony</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->

                        <article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto3.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Ms Erika Send Off Ceremony</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->


                         
                        <article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto6.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Ms Pauline Send Off Ceremony</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->


                        <article class="blog-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="">
                                        <img src="img/mcphotos/mcphoto5.jpg" class="img-thumbnail center-block" alt="Blog Post Thumbnail">
                                    </a>
                                </div>
                                <div class="col-md-9">                                
                                    <h1>
                                        <a href="">Mr &  Mrs Joel Wedding Ceremony</a>
                                    </h1>
                                    <p>A send off party which was on 26/01/2016, held at Mlimani City Dar es salaam, the MC was <a href="">MC JIMMY</a> photography by <a href="">ALLEN STUDIO</a> salon by <a href="">PRINCESS BEAUTY</a>...</p>
                                    <div type="button" class="btn btn-danger">READ MORE
                                        
                                    </div>
                                     <div class="fix post-meta">
                                    <p>Posted by Admin|26 Sep, 2012  |  24 Comments</p>
                                     </div>
                                </div>
                            </div>

                        </article> <!-- /.blog-item -->


                        <div class="page-turn">
                            <div class="row">
                                <div class="col-md-6 col-md-offset-3 text-center">
                                    <nav>
                                        <ul class="pagination pagination-sm">
                                            <li class="disabled">
                                                <a href="#" aria-label="Previous">
                                                    <span aria-hidden="true">Prev</span>
                                                </a>
                                            </li>
                                            <li class="active"><a href="index.html">1</a></li>
                                            <li><a href="page2.html">2</a></li>
                                            <li><a href="page3.html">3</a></li>
                                            <li><a href="page4.html">4</a></li>
                                            <li><a href="page5.html">5</a></li>
                                            <li>
                                                <a href="page6.html" aria-label="Next">
                                                    <span aria-hidden="true">Next</span>
                                                </a>
                                            </li>
                                        </ul> <!-- /.pagination -->
                                    </nav>
                                </div>
                            </div>
                        </div> <!-- /.page-turn -->

                    </section>
                    <!-- end of blog-contents -->

                    <!-- sidebar -->
                    <aside class="col-md-4 col-sm-8 col-xs-8">
                        <div class="sidebar">

                            <!-- search option -->
                            <div class="search-widget">
                                <div class="input-group margin-bottom-sm">
                                    <input class="form-control" type="text" placeholder="Search here">
                                    <a href="#" class="input-group-addon">
                                        <i class="fa fa-search fa-fw"></i>
                                    </a>
                                </div>
                            </div>

                             <div class="popular_post ">
                                <h2>POPULAR POSTS</h2>
                                <div class=" single_popular">
                                    <img src="img/mcphotos/mcphoto5.jpg" height="90px" width="90px" class="floatleft"/>
                                    <h2><a href="">Ms Pauline Send Off Ceremony</a></h2>
                                    <p>12 Nov, 2012</p>
                                </div>
                                <div class=" single_popular">
                                    <img src="img/mcphotos/mcphoto4.jpg"  height="90px" width="90px" class="floatleft"/>
                                    <h2><a href="">Ms Queen Kitchen Party</a></h2>
                                    <p>12 Nov, 2012</p>
                                </div>
                                <div class=" single_popular">
                                    <img src="img/mcphotos/mcphoto6.jpg"  height="90px" width="90px" class="floatleft"/>
                                    <h2><a href="">Mr & Mrs Chacha Wedding Ceremony</a></h2>
                                    <p>12 Nov, 2012</p>
                                </div>
                             </div>     <!-- end of popular post -->

                        </div>
                    </aside> 
                    <!-- end of sidebar -->

                </div>
            </div> <!-- end of /.container -->
        </main>

             <?php include 'inc/footer.inc.php';?>


        <!--  Necessary scripts  -->

        <script type="text/javascript" src="assets/js/jquery-2.1.3.min.js"></script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="assets/js/jQuery.scrollSpeed.js"></script>

        <!-- smooth-scroll -->

        <script>
        $(function() {  
            jQuery.scrollSpeed(100, 1000);
        });
        </script>

    </body>
</html>